<template>
<section class="welcome">
    <h2 class="welcome_title">
        welcome
    </h2>
    <button @click="$emit('start')" class="welcome_button">
        start
    </button>
</section>
</template>

<script>
export default {
    name: 'WelcomeSection'
}
</script>

<style lang="scss" scoped>
.welcome{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 60px;
    width: 350px;

    &_title{
        color:  #2ecc71;
        font-size: 6rem;
    }
    &_button{
        background: #000;
        color:  #2ecc71;
        font-size: 2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 10px 40px;
        box-shadow: 1px 1px 15px #2ecc71, -1px -1px 15px #2ecc71;
        outline: none;
        border: none;
    }

}
</style>