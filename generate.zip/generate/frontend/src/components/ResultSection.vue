<template>
    <div class="ca-container" @click="textCopy">
        ca: <span>jfklsdjfkldsjfkldsjfksdjfkldsjfkdsl</span>
    </div>
    <div class="back">
        <pre class="back_ascii">
            {{ ascii }}
        </pre>
        <button @click="$emit('back')" class="back_button">
            back
        </button>
    </div>
    <img src="@/assets/x.webp" alt="">
</template>

<script>
export default {
    name: 'BackSection',
    props: {
        ascii: String
    },
    methods: {
        textCopy() {
            navigator.clipboard.writeText('comingsoon')
        }
    }
}
</script>

<style lang="scss" scoped>
.ca-container {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    font-size: 1.2rem;
    color: #2ecc71;
    gap: 10px;

    span {
        font-size: 1rem;
        background: #000;
        border-radius: 30px;
        border: 1px solid #2ecc71;
        color: #2ecc71;
        padding: 4px 10px;
    }
}

img {
    box-shadow: 1px 1px 15px #2ecc71, -1px -1px 15px #2ecc71;
    width: 42px;
    height: 42px;
    border-radius: 50%;
    margin-top: 20px;
}

.back {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 60px;
    box-shadow: 1px 1px 15px #2ecc71, -1px -1px 15px #2ecc71;
    background: #000;
    padding: 40px;
    width: 350px;

    &_ascii {
        width: 256px;
        height: 256px;
        font-family: monospace;
        background-color: #f0f0f0;
        border-radius: 5px;
        overflow-x: hidden;
        overflow-y: hidden;
        background: #000;
        color: #2ecc71;
        font-size: 1px;
    }

    &_button {
        background: #000;
        color: #2ecc71;
        font-size: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 10px 40px;
        box-shadow: 1px 1px 15px #2ecc71, -1px -1px 15px #2ecc71;
        outline: none;
        border: none;
    }

}
</style>