<template>
<div class="prompt">
    <h2 class="prompt_title">
        enter your prompt
    </h2>
    <input v-model="prompt" type="text">
    <button @click="$emit('generate', prompt)" class="prompt_button">
        generate
    </button>
</div>
</template>

<script>
export default {
    name: 'PromptSection',
    data: () => ({
        prompt: ''
    })
}
</script>

<style lang="scss" scoped>
.prompt{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 60px;
    box-shadow: 1px 1px 15px #2ecc71, -1px -1px 15px #2ecc71;
    background: #000;
    padding: 40px;
    width: 350px;

    &_title{
        color:  #2ecc71;
        font-size: 1.5rem;
    }
    input{
        border: 1px solid #2ecc71;
        height: 2rem;
        width: 80%;
        background: #000;
        outline: none;
        color: #2ecc71;
        font-family: "Quantico", serif;
        padding: 0 10px;
    }
    &_button{
        background: #000;
        color:  #2ecc71;
        font-size: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 10px 40px;
        box-shadow: 1px 1px 15px #2ecc71, -1px -1px 15px #2ecc71;
        outline: none;
        border: none;
    }

}
</style>