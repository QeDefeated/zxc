<template>
  <main>
    <WelcomeSection v-if="activeSection == 0" @start="onStart" />
    <PromptSection v-if="activeSection == 1" @generate="onGenerate" />
    <LoaderSection v-if="activeSection == 2" />
    <BackSection v-if="activeSection == 3" @back="onBack" :ascii="ascii" />
  </main>
</template>

<script>
import WelcomeSection from '@/components/WelcomeSection.vue'
import PromptSection from '@/components/PromptSection.vue'
import LoaderSection from '@/components/LoaderSection.vue'
import BackSection from '@/components/ResultSection.vue'

import { gsap } from "gsap";
export default {
  name: 'App',
  data: () => ({
    activeSection: 0,
    ascii: ''
  }),
  methods: {
    onBack() {
      const height = window.innerHeight
      this.activeSection = 0
      this.ascii = ''
      gsap.from(".welcome", {
        y: -height,
        scale: .9,
        duration: 1,
        ease: "power2.in",
      });
    },
    onStart() {
      const height = window.innerHeight
      gsap.to(".welcome", {
        y: -height,
        scale: .9,
        duration: 1,
        ease: "power2.out",
        onComplete: () => {
          this.activeSection = 1
          gsap.from(".welcome", {
            y: height,
            scale: .9,
            duration: 1,
            ease: "power2.in",
            onComplete: () => {
            }
          });
        }
      });
    },
    onGenerate(prompt) {
      const height = window.innerHeight
      gsap.to(".prompt", {
        y: -height,
        scale: .9,
        duration: 1,
        ease: "power2.out",
        onComplete: () => {
          this.activeSection = 2
          gsap.from(".loader", {
            y: height,
            scale: .9,
            duration: 1,
            ease: "power2.in",
            onComplete: () => {
            }
          });
        }
      });

      fetch('/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt
        })
      })
        .then(response => response.json())
        .then(data => {
          this.ascii = data.ascii;
          gsap.to(".loader", {
            y: -height,
            scale: .9,
            duration: 1,
            ease: "power2.out",
            onComplete: () => {
              this.activeSection = 3
              gsap.from(".back", {
                y: height,
                scale: .9,
                duration: 1,
                ease: "power2.in",
              });
            }
          });
        })
        .catch(error => {
          console.error('Error:', error);
        });
    }
  },
  components: {
    WelcomeSection,
    PromptSection,
    LoaderSection,
    BackSection
  }
}
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Quantico:ital,wght@0,400;0,700;1,400;1,700&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Quantico", serif;
  font-weight: 400;
  font-style: normal;
}

main {
  background: url(@/assets/sphere.png) no-repeat, #000;
  background-size: cover;
  background-position: center;
  min-height: 100vh;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}

.quantico-bold {
  font-family: "Quantico", serif;
  font-weight: 700;
  font-style: normal;
}

.quantico-regular-italic {
  font-family: "Quantico", serif;
  font-weight: 400;
  font-style: italic;
}

.quantico-bold-italic {
  font-family: "Quantico", serif;
  font-weight: 700;
  font-style: italic;
}
</style>
