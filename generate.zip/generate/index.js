const express = require('express');
const axios = require('axios');
const imageToAscii = require('image-to-ascii');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'frontend', 'dist')));


function convertImageToAscii(imagePath) {
    console.log(imagePath);
    return new Promise((resolve, reject) => {
        imageToAscii(imagePath, {
            size: {
                height: 256,
                width: 256
            },
            pxWidth: 1,
            pixels: " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$",
            colored: false,
            white_bg: true,
            size_options: {
                fit_screen: false, 
            },
        }, (err, converted) => {
            if (err) {
                reject(err);
            } else {
                resolve(converted);
            }
        });
    });
}

const generateImage = async (prompt) => {
    const apiUrl = 'https://api.bfl.ml/v1/flux-pro-1.1';
    try {
        const response = await axios.post(apiUrl, {
            prompt,
            width: 1440,
            height: 1440,
            prompt_upsampling: false,
            seed: 42,
            safety_tolerance: 2,
            output_format: 'jpeg',
        }, {
            headers: {
                'X-Key': '25b34f29-8bd1-4f5b-b03a-3af85fe1eb46',
            },
        });
        return response.data.id;
    } catch (error) {
        throw new Error('Error generating image: ' + error.message);
    }
};

const getGenerateResult = async (id = '') => {
    const apiUrl = `https://api.bfl.ml/v1/get_result?id=${id}`;
    let result;

    const fetchImage = async () => {
        try {
            const response = await axios.get(apiUrl, {
                headers: {
                    'X-Key': '25b34f29-8bd1-4f5b-b03a-3af85fe1eb46',
                },
            });
            result = response;
            return response;
        } catch (error) {
            throw new Error('Error fetching image: ' + error.message);
        }
    };

    while (true) {
        await fetchImage();
        if (result.data?.status === 'Pending') {
            console.log('Status: Pending, retrying...');
            await new Promise(resolve => setTimeout(resolve, 1000));
        } else {
            break;
        }
    }

    if (result?.data?.result?.sample) {
        return await convertImageToAscii(result.data.result.sample);
    } else {
        throw new Error('No image data available');
    }
};

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'dist', 'index.html'));
});

app.post('/generate', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
    }

    try {
        const id = await generateImage(prompt);
        const asciiArt = await getGenerateResult(id);
        res.json({ ascii: asciiArt });
    } catch (error) {
        console.error('Error generating ASCII:', error.message);
        res.status(500).json({ error: 'Failed to generate ASCII art' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
