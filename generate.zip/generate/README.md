npm install

start on server:
node index